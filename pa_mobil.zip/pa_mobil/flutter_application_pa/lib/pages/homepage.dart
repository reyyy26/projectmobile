import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:firebase_storage/firebase_storage.dart';
import 'package:flutter/material.dart';
import 'package:flutter_application_pa/pages/predictPage.dart';
import 'package:flutter_secure_storage/flutter_secure_storage.dart';

class MyHomePage extends StatefulWidget {
  const MyHomePage({super.key});

  @override
  State<MyHomePage> createState() => _MyHomePageState();
}

class _MyHomePageState extends State<MyHomePage> {
  int _selectedIndex = 0;
  String? _username;
  String? _profilePictureUrl; // Variabel untuk menyimpan URL gambar profil
  final _storage = FlutterSecureStorage();

  static const List<String> _appBarTitles = ['Home', 'Identifikasi', 'Others'];

  @override
  void initState() {
    super.initState();
    _loadUserSession();
  }

  // Memuat sesi pengguna dan URL gambar profil dari Firestore
  void _loadUserSession() async {
    String? storedUsername = await _storage.read(key: 'username');
    if (storedUsername != null) {
      setState(() {
        _username = storedUsername;
      });
      _loadProfilePicture(storedUsername);
    }
  }

  // Memuat URL gambar profil pengguna dari Firestore
  void _loadProfilePicture(String username) async {
    DocumentSnapshot userDoc = await FirebaseFirestore.instance
        .collection('users')
        .doc(username)
        .get();
    if (userDoc.exists) {
      setState(() {
        _profilePictureUrl = userDoc['profile_picture'];
      });
    }
  }

  // Logout functionality
  void _logout() async {
    await _storage.delete(key: 'username');
    setState(() {
      _username = null;
      _profilePictureUrl = null;
    });
    Navigator.pushReplacementNamed(context, '/login');
  }

  final List<Widget> widgetOptions = <Widget>[
    //1 HOMEPAGE
    const Text('ini -homepage'),

    //2 identiti
    // const MyHistoryPage(),
    PredictPage(),

    //3 lainnya
    // const MySettingPage(),
    const Text('ini lainnya'),
  ];

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        leading: Builder(
          builder: (context) => IconButton(
            icon: const Icon(Icons.menu, size: 30),
            onPressed: () {
              Scaffold.of(context).openDrawer();
            },
          ),
        ),
        title: Text(
          _appBarTitles[_selectedIndex],
          style:
              const TextStyle(color: Colors.white, fontWeight: FontWeight.bold),
        ),
        backgroundColor: const Color(0xFF107115),
        actions: [
          IconButton(
            icon: const Icon(Icons.settings),
            onPressed: () {
              Navigator.pushNamed(context, '/settings');
            },
          ),
        ],
      ),
      drawer: Drawer(
        backgroundColor: Theme.of(context).canvasColor,
        child: Column(
          children: [
            // Tampilkan gambar profil dari Firestore
            _username == null
                ? const UserAccountsDrawerHeader(
                    currentAccountPicture: CircleAvatar(
                      backgroundImage: AssetImage('assets/default_avatar.jpg'),
                    ),
                    accountName: Text("HOLA"),
                    accountEmail: Text('Guest'),
                    decoration: BoxDecoration(color: Color(0xFF107115)),
                  )
                : UserAccountsDrawerHeader(
                    currentAccountPicture: CircleAvatar(
                      backgroundImage: _profilePictureUrl != null
                          ? NetworkImage(_profilePictureUrl!)
                          : AssetImage('assets/default_avatar.jpg')
                              as ImageProvider,
                    ),
                    accountName: Text('Welcome, $_username'),
                    accountEmail: Text('$_username'),
                    decoration: const BoxDecoration(color: Color(0xFF107115)),
                  ),
            ListTile(
              leading: const Icon(Icons.account_circle),
              title: const Text('Profile'),
              onTap: () {
                Navigator.pushNamed(context, '/profile');
              },
            ),
            ListTile(
              leading: const Icon(Icons.logout),
              title: const Text('Logout'),
              onTap: _logout,
            ),
          ],
        ),
      ),
      body: Center(
        child: widgetOptions.elementAt(_selectedIndex),
      ),
      bottomNavigationBar: BottomNavigationBar(
        backgroundColor: const Color(0xFF107115),
        items: const <BottomNavigationBarItem>[
          BottomNavigationBarItem(
            icon: Icon(Icons.home),
            label: 'Home',
          ),
          BottomNavigationBarItem(
            icon: Icon(Icons.camera),
            label: 'Identifikasi',
          ),
          BottomNavigationBarItem(
            icon: Icon(Icons.settings),
            label: 'Others',
          ),
        ],
        currentIndex: _selectedIndex,
        selectedItemColor: Colors.white,
        onTap: (index) {
          setState(() {
            _selectedIndex = index;
          });
        },
      ),
    );
  }
}
