import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import 'package:flutter_application_pa/models/theme_provider.dart';



class MySettingPage extends StatefulWidget {
  const MySettingPage({super.key});

  @override
  State<MySettingPage> createState() => _MySettingPageState();
}

class _MySettingPageState extends State<MySettingPage> {
  // bool darkOn = false;
  
  bool incognitoOn = false;
  @override
  Widget build(BuildContext context) {
    final themeProvider = Provider.of<ThemeProvider>(context);
    
    return Scaffold(
      appBar: AppBar(
         leading: Builder(
            builder: (context) => IconButton(
              //icon bagian kiri untuk kembali
                icon: const Icon(
                  Icons.arrow_back,
                  size: 30,
                ),
                onPressed: () {
                  Navigator.pop(context);
                },
              ),
          ),
          title: const Text('Pengaturan'),
          //icon bagian kanan
          actions: [
            IconButton(
              icon: const Icon(Icons.search),
              onPressed: () {},
            ),
          ],
      ),
      body: ListView(
        children: [
          ListTile(
            leading: const Icon(Icons.dark_mode, color: Colors.blue),
            title: const Text('drak mode'),
            subtitle:
                const Text('mengaktifkan dark mode dengan tema kegelapan'),
            trailing: Switch(
                value: themeProvider.isDarkMode,
                activeColor: Colors.blueAccent,
                onChanged: (bool value) {
                themeProvider.toggleTheme(value);
              },
               ),
          ),
          ListTile(
            leading:
                const Icon(Icons.visibility_off_outlined, color: Colors.blue),
            title: const Text('mode penyamaran / inconigto'),
            subtitle: const Text('Jeda Riwayat'),
            trailing: Switch(
                value: incognitoOn,
                activeColor: Colors.blueAccent,
                onChanged: (bool value) {
                  setState(() {
                    incognitoOn = value;
                  });
                }),
          ),
        ],
      ),
    );
  }
}
