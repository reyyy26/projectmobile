import 'dart:io';
import 'package:flutter/material.dart';
import 'package:image_picker/image_picker.dart';
import 'package:http/http.dart' as http;
import 'dart:convert';

class PredictPage extends StatefulWidget {
  @override
  _PredictPageState createState() => _PredictPageState();
}

class _PredictPageState extends State<PredictPage> {
  File? _image;
  final ImagePicker _picker = ImagePicker();

  // Fungsi untuk mengambil gambar dari kamera
  Future<void> _getImageFromCamera() async {
    final pickedFile = await _picker.pickImage(source: ImageSource.camera);

    if (pickedFile != null) {
      setState(() {
        _image = File(pickedFile.path);
      });
    }
  }

  // Fungsi untuk mengambil gambar dari galeri
  Future<void> _pickImageFromGallery() async {
    final pickedFile = await _picker.pickImage(source: ImageSource.gallery);

    if (pickedFile != null) {
      setState(() {
        _image = File(pickedFile.path);
      });
    }
  }

  // Fungsi untuk mengirim gambar ke Flask untuk prediksi
  Future<void> _sendImageToFlask() async {
    if (_image == null) {
      return;
    }

    var uri = Uri.parse(
        'https://classify.roboflow.com/rice-plant-leaf-disease-classification/1?api_key=5gOJ8v7HoEPKM73z4sIk'); // URL
    // var uri = Uri.parse('http://192.168.63.44:5000/predict');
    var request = http.MultipartRequest('POST', uri);
    var pic = await http.MultipartFile.fromPath('file', _image!.path);
    request.files.add(pic);

    var response = await request.send();
    if (response.statusCode == 200) {
      var responseData = await response.stream.bytesToString();
      var jsonResponse = jsonDecode(responseData);

      // Memformat hasil prediksi
      String formattedResult = _formatPredictionResult(jsonResponse);

      // Tampilkan hasil prediksi dalam dialog
      showDialog(
        context: context,
        builder: (BuildContext context) {
          return AlertDialog(
            title: Text('Hasil Prediksi'),
            content: Text(formattedResult),
            actions: [
              TextButton(
                child: Text('OK'),
                onPressed: () {
                  Navigator.of(context).pop();
                },
              ),
            ],
          );
        },
      );
    } else {
      print('Failed to predict');
    }
  }

  // Fungsi untuk memformat hasil prediksi agar lebih mudah dibaca
  String _formatPredictionResult(Map<String, dynamic> jsonResponse) {
    String result =
        'Prediksi Terbaik: ${jsonResponse['top']}\n\nTingkat Kepercayaan Diri ${jsonResponse['predictions'][0]['confidence'] * 100}%\n\nHasil Prediksi:\n';
    for (var prediction in jsonResponse['predictions']) {
      result += '${prediction['class']}: ${prediction['confidence'] * 100}%\n';
    }
    return result;
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: SingleChildScrollView(
        // Membungkus seluruh konten dalam SingleChildScrollView untuk mencegah overflow
        child: Padding(
          padding: const EdgeInsets.all(16.0),
          child: Column(
            mainAxisAlignment: MainAxisAlignment.center,
            crossAxisAlignment: CrossAxisAlignment.center,
            children: <Widget>[
              // Menambahkan widget Expanded untuk gambar agar tidak overflow
              _image == null
                  ? Text('Tidak ada gambar yang dipilih')
                  : Image.file(
                      _image!,
                      width: MediaQuery.of(context).size.width *
                          0.8, // Membuat gambar responsif
                      height: MediaQuery.of(context).size.height *
                          0.3, // Membatasi tinggi gambar agar responsif
                      fit: BoxFit
                          .cover, // Agar gambar terpotong secara proporsional
                    ),
              SizedBox(height: 20),
              ElevatedButton(
                onPressed: _getImageFromCamera,
                child: Text('Ambil Gambar dari Kamera'),
              ),
              SizedBox(height: 20),
              ElevatedButton(
                onPressed: _pickImageFromGallery,
                child: Text('Pilih Gambar dari Galeri'),
              ),
              SizedBox(height: 20),
              ElevatedButton(
                onPressed: _sendImageToFlask,
                child: Text('Deteksi Penyakit'),
              ),
            ],
          ),
        ),
      ),
    );
  }
}
