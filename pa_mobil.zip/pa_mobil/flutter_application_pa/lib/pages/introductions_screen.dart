import 'package:flutter/material.dart';
import 'package:introduction_screen/introduction_screen.dart';

class IntroductionPage extends StatelessWidget {
  const IntroductionPage({super.key});

  @override
  Widget build(BuildContext context) {
    return IntroductionScreen(
      next: const Text("Selanjutnya"),
      done: const Text("Selesai"),
      onDone: () {
        Navigator.pushReplacementNamed(context, '/');
      },
      pages: [
        PageViewModel(
          title: "Selamat Datang di Aplikasi Klasifikasi Penyakit Padi",
          body: "Aplikasi ini membantu Anda mengenali berbagai jenis penyakit pada tanaman padi berdasarkan gambar.",
          image: Image.network("https://pertanian-mesuji.id/wp-content/uploads/2018/04/klasifikasi-dan-morfologi-padi.jpg"),
        ),
        PageViewModel(
          title: "Langkah 1: Ambil atau Pilih Gambar Tanaman Padi",
          body: "Anda dapat mengambil gambar tanaman padi menggunakan kamera atau memilih gambar dari galeri.",
          image: Image.network("https://jatimulyo.kec-petanahan.kebumenkab.go.id/uploads/gambar/22102022120235-Jatimulyo-Kebumen-gutama.jpg"),
        ),
        PageViewModel(
          title: "Langkah 2: Hasil Klasifikasi",
          body: "Setelah gambar dianalisis, aplikasi akan menampilkan jenis penyakit pada padi beserta informasinya.",
          image: Image.network("https://stockistnasa.com/wp-content/uploads/2012/04/teknis-budidaya-padi-nasa.jpg"),
        ),
        PageViewModel(
          title: "Mulai Menggunakan Aplikasi",
          body: "Tekan tombol 'Selesai' untuk mulai menggunakan aplikasi.",
          image: Image.network("https://independensi.com/wp-content/uploads/2018/04/Budidaya-padi-sehat.jpg"),
        ),
      ],
    );
  }
}
