from flask import Flask, request, jsonify
from flask_cors import CORS
from inference_sdk import InferenceHTTPClient

app = Flask(__name__)
CORS(app)

CLIENT = InferenceHTTPClient(
    api_url="https://classify.roboflow.com",
    api_key="5gOJ8v7HoEPKM73z4sIk"
)

# Endpoint untuk prediksi
@app.route('/predict', methods=['POST'])
def predict():
    if 'file' not in request.files:
        return jsonify({'error': 'Tidak ada file yang diunggah'}), 400

    file = request.files['file']
    file_path = 'temp_image.jpg'
    file.save(file_path)  # Simpan gambar sementara untuk diproses

    # Lakukan inferensi menggunakan Roboflow
    result = CLIENT.infer(file_path, model_id="rice-plant-leaf-disease-classification/1")
    # Simpan hasil ke dalam output.txt
    with open('output.txt', 'w') as f:
        # f.write(str(result.json()))
        f.write(str(result))

    # Menampilkan hasil prediksi dalam format JSON
    return jsonify(result)

    # Tambahkan pengaturan timeout di sini
    app.config['JSONIFY_PRETTYPRINT_REGULAR'] = False
    app.config['MAX_CONTENT_LENGTH'] = 16 * 1024 * 1024  # Maksimum ukuran file (contoh 16 MB)

if __name__ == '__main__':
    app.run(debug=True, host='0.0.0.0', port=5000)
